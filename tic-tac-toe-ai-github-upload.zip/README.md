# Tic-Tac-Toe AI – Minimax with Alpha-Beta Pruning

Mini project for 24AI301 – Artificial Intelligence and Data Science
R.M.K. Engineering College | Hasini Ambati (111725201049)

- `tictactoe_ai.py` – console game, plus Minimax vs Alpha-Beta node-count comparison (option 2)
- `tictactoe_gui.py` – Tkinter GUI (human X vs unbeatable AI O)

Run: `python tictactoe_ai.py` or `python tictactoe_gui.py` (Python 3.8+)

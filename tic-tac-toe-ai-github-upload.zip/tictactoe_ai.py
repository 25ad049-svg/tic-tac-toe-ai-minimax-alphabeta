"""
Tic-Tac-Toe AI using Minimax and Alpha-Beta Pruning
24AI301 - Artificial Intelligence and Data Science (Mini Project)
"""

import math
import time

HUMAN = "X"
AI = "O"
EMPTY = " "

WIN_LINES = [
    (0, 1, 2), (3, 4, 5), (6, 7, 8),   # rows
    (0, 3, 6), (1, 4, 7), (2, 5, 8),   # columns
    (0, 4, 8), (2, 4, 6),              # diagonals
]


# ---------------------------------------------------------------- Game engine
def new_board():
    return [EMPTY] * 9


def print_board(board):
    print()
    for r in range(3):
        row = board[3 * r: 3 * r + 3]
        print(" " + " | ".join(row))
        if r < 2:
            print("---+---+---")
    print()


def winner(board):
    for a, b, c in WIN_LINES:
        if board[a] != EMPTY and board[a] == board[b] == board[c]:
            return board[a]
    return None


def is_full(board):
    return EMPTY not in board


def available_moves(board):
    return [i for i, v in enumerate(board) if v == EMPTY]


def game_over(board):
    return winner(board) is not None or is_full(board)


# ------------------------------------------------------------------ Evaluation
def evaluate(board, depth):
    """+10 - depth if AI wins, depth - 10 if human wins, 0 for a draw.
    Depth is used so that the AI prefers faster wins and slower losses."""
    w = winner(board)
    if w == AI:
        return 10 - depth
    if w == HUMAN:
        return depth - 10
    return 0


# ------------------------------------------------------------ Plain Minimax
nodes_minimax = 0


def minimax(board, depth, is_maximizing):
    global nodes_minimax
    nodes_minimax += 1

    if game_over(board):
        return evaluate(board, depth)

    if is_maximizing:
        best = -math.inf
        for m in available_moves(board):
            board[m] = AI
            best = max(best, minimax(board, depth + 1, False))
            board[m] = EMPTY
        return best
    else:
        best = math.inf
        for m in available_moves(board):
            board[m] = HUMAN
            best = min(best, minimax(board, depth + 1, True))
            board[m] = EMPTY
        return best


def best_move_minimax(board):
    global nodes_minimax
    nodes_minimax = 0
    best_score, best_m = -math.inf, None
    for m in available_moves(board):
        board[m] = AI
        score = minimax(board, 1, False)
        board[m] = EMPTY
        if score > best_score:
            best_score, best_m = score, m
    return best_m, nodes_minimax


# ------------------------------------------------- Minimax + Alpha-Beta Pruning
nodes_alphabeta = 0


def alphabeta(board, depth, alpha, beta, is_maximizing):
    global nodes_alphabeta
    nodes_alphabeta += 1

    if game_over(board):
        return evaluate(board, depth)

    if is_maximizing:
        value = -math.inf
        for m in available_moves(board):
            board[m] = AI
            value = max(value, alphabeta(board, depth + 1, alpha, beta, False))
            board[m] = EMPTY
            alpha = max(alpha, value)
            if alpha >= beta:          # beta cut-off
                break
        return value
    else:
        value = math.inf
        for m in available_moves(board):
            board[m] = HUMAN
            value = min(value, alphabeta(board, depth + 1, alpha, beta, True))
            board[m] = EMPTY
            beta = min(beta, value)
            if alpha >= beta:          # alpha cut-off
                break
        return value


def best_move_alphabeta(board):
    global nodes_alphabeta
    nodes_alphabeta = 0
    best_score, best_m = -math.inf, None
    alpha, beta = -math.inf, math.inf
    for m in available_moves(board):
        board[m] = AI
        score = alphabeta(board, 1, alpha, beta, False)
        board[m] = EMPTY
        if score > best_score:
            best_score, best_m = score, m
        alpha = max(alpha, best_score)
    return best_m, nodes_alphabeta


# --------------------------------------------------------------- Game loop
def human_turn(board):
    while True:
        try:
            pos = int(input("Your move (1-9): ")) - 1
        except ValueError:
            print("Please enter a number between 1 and 9.")
            continue
        if pos not in range(9):
            print("Out of range. Choose 1-9.")
        elif board[pos] != EMPTY:
            print("That cell is already taken.")
        else:
            return pos


def ai_turn(board):
    start = time.perf_counter()
    move, nodes = best_move_alphabeta(board)
    elapsed = (time.perf_counter() - start) * 1000
    print(f"AI plays {move + 1}  (nodes searched: {nodes}, time: {elapsed:.2f} ms)")
    return move


def play():
    board = new_board()
    print("TIC-TAC-TOE  |  You = X, AI = O")
    print("Cells are numbered 1-9, left to right, top to bottom.")
    print_board(board)
    turn = HUMAN
    while not game_over(board):
        if turn == HUMAN:
            board[human_turn(board)] = HUMAN
            turn = AI
        else:
            board[ai_turn(board)] = AI
            turn = HUMAN
        print_board(board)

    w = winner(board)
    if w == HUMAN:
        print("You win!")
    elif w == AI:
        print("AI wins!")
    else:
        print("It's a draw!")


def compare_algorithms():
    """Compares Minimax and Alpha-Beta on the empty board and after one move."""
    print("PERFORMANCE COMPARISON (AI = O, moves first for this test)")
    print("-" * 62)
    print(f"{'Position':<22}{'Algorithm':<14}{'Nodes':>10}{'Time (ms)':>12}{'Move':>6}")
    print("-" * 62)
    tests = {
        "Empty board": new_board(),
        "X in centre": [" ", " ", " ", " ", "X", " ", " ", " ", " "],
        "X in corner": ["X", " ", " ", " ", " ", " ", " ", " ", " "],
    }
    for name, b in tests.items():
        for label, fn in (("Minimax", best_move_minimax), ("Alpha-Beta", best_move_alphabeta)):
            t = time.perf_counter()
            move, nodes = fn(b[:])
            ms = (time.perf_counter() - t) * 1000
            print(f"{name:<22}{label:<14}{nodes:>10}{ms:>12.2f}{move + 1:>6}")
    print("-" * 62)


if __name__ == "__main__":
    print("1. Play against the AI")
    print("2. Compare Minimax vs Alpha-Beta")
    choice = input("Choose an option (1/2): ").strip()
    if choice == "2":
        compare_algorithms()
    else:
        play()

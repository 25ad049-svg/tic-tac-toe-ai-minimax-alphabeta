import tkinter as tk
from tkinter import messagebox

HUMAN = "X"
AI = "O"
EMPTY = ""

WINNING_LINES = [
    (0, 1, 2), (3, 4, 5), (6, 7, 8),  # Rows
    (0, 3, 6), (1, 4, 7), (2, 5, 8),  # Columns
    (0, 4, 8), (2, 4, 6)              # Diagonals
]


def get_winner(board):
    """Return X or O if a player has won, otherwise None."""
    for a, b, c in WINNING_LINES:
        if board[a] != EMPTY and board[a] == board[b] == board[c]:
            return board[a]
    return None


def is_draw(board):
    """Return True when the board is full and nobody has won."""
    return get_winner(board) is None and EMPTY not in board


def minimax(board, depth, is_maximizing, alpha, beta):
    """
    Minimax with Alpha-Beta pruning.
    AI (O) tries to maximize the score; Human (X) tries to minimize it.
    Depth makes the AI prefer quicker wins and slower losses.
    """
    winner = get_winner(board)

    if winner == AI:
        return 10 - depth
    if winner == HUMAN:
        return depth - 10
    if EMPTY not in board:
        return 0

    if is_maximizing:
        best_score = float("-inf")
        for i in range(9):
            if board[i] == EMPTY:
                board[i] = AI
                score = minimax(board, depth + 1, False, alpha, beta)
                board[i] = EMPTY
                best_score = max(best_score, score)
                alpha = max(alpha, best_score)
                if beta <= alpha:
                    break  # Alpha-Beta pruning
        return best_score

    best_score = float("inf")
    for i in range(9):
        if board[i] == EMPTY:
            board[i] = HUMAN
            score = minimax(board, depth + 1, True, alpha, beta)
            board[i] = EMPTY
            best_score = min(best_score, score)
            beta = min(beta, best_score)
            if beta <= alpha:
                break  # Alpha-Beta pruning
    return best_score


def find_best_move(board):
    """Find the best empty square for the AI."""
    best_score = float("-inf")
    best_move = None

    for i in range(9):
        if board[i] == EMPTY:
            board[i] = AI
            score = minimax(
                board, 0, False, float("-inf"), float("inf")
            )
            board[i] = EMPTY

            if score > best_score:
                best_score = score
                best_move = i

    return best_move


class TicTacToeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Tic-Tac-Toe AI - Minimax & Alpha-Beta Pruning")
        self.root.resizable(False, False)
        self.board = [EMPTY] * 9
        self.game_over = False
        self.buttons = []

        title = tk.Label(
            root,
            text="Tic-Tac-Toe AI",
            font=("Arial", 20, "bold"),
            padx=16,
            pady=12
        )
        title.grid(row=0, column=0, columnspan=3)

        self.status = tk.Label(
            root,
            text="Your turn (X)",
            font=("Arial", 12),
            pady=8
        )
        self.status.grid(row=1, column=0, columnspan=3)

        for i in range(9):
            button = tk.Button(
                root,
                text="",
                font=("Arial", 24, "bold"),
                width=5,
                height=2,
                command=lambda index=i: self.human_move(index)
            )
            button.grid(row=2 + i // 3, column=i % 3, padx=4, pady=4)
            self.buttons.append(button)

        restart_button = tk.Button(
            root,
            text="Restart Game",
            font=("Arial", 12),
            command=self.restart_game
        )
        restart_button.grid(row=5, column=0, columnspan=3, pady=12)

    def human_move(self, index):
        if self.game_over or self.board[index] != EMPTY:
            return

        self.board[index] = HUMAN
        self.buttons[index].config(text=HUMAN, state="disabled")
        if self.finish_if_needed():
            return

        self.status.config(text="AI is thinking...")
        self.root.after(250, self.ai_move)

    def ai_move(self):
        if self.game_over:
            return

        move = find_best_move(self.board)
        if move is not None:
            self.board[move] = AI
            self.buttons[move].config(text=AI, state="disabled")

        if not self.finish_if_needed():
            self.status.config(text="Your turn (X)")

    def finish_if_needed(self):
        winner = get_winner(self.board)

        if winner == HUMAN:
            self.game_over = True
            self.status.config(text="You win!")
            messagebox.showinfo("Game Over", "Congratulations! You win.")
            self.disable_empty_buttons()
            return True

        if winner == AI:
            self.game_over = True
            self.status.config(text="AI wins!")
            messagebox.showinfo("Game Over", "The AI wins. Try again!")
            self.disable_empty_buttons()
            return True

        if is_draw(self.board):
            self.game_over = True
            self.status.config(text="It's a draw!")
            messagebox.showinfo("Game Over", "The game is a draw.")
            return True

        return False

    def disable_empty_buttons(self):
        for i, button in enumerate(self.buttons):
            if self.board[i] == EMPTY:
                button.config(state="disabled")

    def restart_game(self):
        self.board = [EMPTY] * 9
        self.game_over = False
        for button in self.buttons:
            button.config(text="", state="normal")
        self.status.config(text="Your turn (X)")


if __name__ == "__main__":
    window = tk.Tk()
    app = TicTacToeApp(window)
    window.mainloop()
